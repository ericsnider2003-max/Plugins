# Usage-max source matrix v1

This is the Stage 0 contract boundary. It records what a source is allowed to prove; it does not claim that every adapter exists yet.

| Surface | Current source | Can prove now | Cannot prove now | Initial state |
|---|---|---|---|---|
| Claude Code | hook payloads and local transcript | local activity, observed model fields | account-wide allowance | observing |
| Claude provider | supported OAuth usage read | provider allowance when fresh | invisible shared-surface activity | observing |
| Codex desktop/CLI | live app-server read, with local rollout fallback | provider allowance, account ID, local activity, model fields when attached | cloud/shared activity outside the source | observing until approved |
| ChatGPT | redacted local host attachment contract; no producer bundled | supplied model and provider-window claims when attached and approved | anything not supplied by the host; no private UI scraping | unavailable until attached |
| Claude Cowork | redacted local host attachment contract; no producer bundled | supplied model and provider-window claims when attached and approved | anything not supplied by the host; no private UI scraping | unavailable until attached |
| Codex cloud | no local adapter | nothing | cloud usage and model | unavailable |
| Browser/mobile | no supported attachment producer | nothing | model, account allowance, shared usage | unavailable |

Rules:

1. Missing data is `unavailable` or `unattributed`, never zero.
2. Local activity is not provider allowance.
3. An estimate cannot authorize routing.
4. Account approval is explicit and bound to a configured slot.
5. A stale, contradictory, or replayed observation is quarantined.
